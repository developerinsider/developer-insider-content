()//: Playground - noun: a place where people can play

import UIKit

/************************************************************
                Constants and Variables
*************************************************************/
 
let constant = 10
//constant = 11

var str = "Hello, playground"
str = "hello"

var welcomeMessage: String
welcomeMessage = "Hello World!!"

var red, green, blue: Double
red = 231/255
green = 232.0/255
blue = 233/255.0

let `let` = 1
let one = 1
let `var` = 2
let two = 2
let `three` = 3

print(`let` + one," ",two)
print(one)




/************************************************************
                            Data Type
 ************************************************************/

Int.max
Int64.max
Int32.max
Int16.max
Int8.max

let decimalIntegerMeaningOfLife = 42
let binaryIntegerMeaningOfLife = 0b101010
let octalIntegerMeaningOfLife = 0o52
let hexadecimalIntegerMeaningOfLife = 0x2A


let oneMillion = 1_000_000
let oneBillion = 1_000_000_000
let paddedDouble = 0001234.567

let uint16:UInt16 = 2_000
let uint8:UInt8 = 200
let addition = uint16 + UInt16(uint8)




/************************************************************
                        typealias
 ************************************************************/

typealias AudioSample = Int8




/************************************************************
                            Bool
 ************************************************************/

let onePlusOneIsTwo = true
let onePlusTwoIsTwo = false

if  onePlusOneIsTwo{
    print(onePlusTwoIsTwo)
}else {
    print(onePlusTwoIsTwo)
}

let i = Bool(1)
if i{
    
}




/************************************************************
                            Tuples
 ************************************************************/

let http404Error = (404, "Not Found")
print("The status code is \(http404Error.0)")
print("The status message is \(http404Error.1)")

let (statusCodeT, statusMessageT) = http404Error
print("The status code is \(statusCodeT)")
print("The status message is \(statusMessageT)")

let (justTheStatusCode, _) = http404Error
print("The status code is \(justTheStatusCode)")

let http200Status = (code:200, description: "OK")
print("The status code is \(http200Status.code)")
print("The status message is \(http200Status.description)")





/************************************************************
                        Tuples vs Struct
 ************************************************************/

let statusCode:(code:Int, message:String) = (404,"Not Found")
statusCode.0
statusCode.1

statusCode.code
statusCode.message

struct statusCodeS{
    static let code:Int = 404
    static let message:String = "Not Found"
}

statusCodeS.code
statusCodeS.message




/************************************************************
                        Optionals
 ************************************************************/
let possibleNumber = "123"
let convertedNumber = Int(possibleNumber)

var serverResponseCode: Int? = 404
serverResponseCode = nil

//nil
if convertedNumber != nil{
    print("convertedNumber contains some integer value")
}

//Optional Binding
if let actualNumber = Int(possibleNumber){
    print("\(possibleNumber) has an integer value of \(actualNumber)")
}else{
    print("\(possibleNumber) could not be converted to an integer")
}

if let firstNumber = Int("4"), secondNumber = Int("42") where firstNumber < secondNumber{
    print("\(firstNumber) < \(secondNumber)")
}

//Implicitly Unwrapped Optionals
let possibleString: String? = "An optional string"
let forcedString: String = possibleString!

let assumedString: String! = "An implicitly unwrapped optional string."
let implicitString: String = assumedString

if assumedString != nil {
    print(assumedString)
}

if let definiteString = assumedString{
    print(definiteString)
}


