//1. Properties
enum Device {
    case iPad
    case iPhone
    
    var year: Int {
        switch self {
        case .iPhone:
            return 2007
        case .iPad:
            return 2010
        }
    }
}

let device = Device.iPhone
print(device.year)



//2. Methods
enum Device1 {
    case iPad
    case iPhone
    
    func introduced() -> String {
        switch self {
        case .iPhone:
            return "\(self) was introduced 2007"
        case .iPad:
            return "\(self) was introduced 2010"
        }
    }
}

let device1 = Device1.iPhone
print (device1.introduced())



//3. Nested Enums
//3.1 Create a Nested Enumerations
enum Character {
    enum Weapon {
        case bow
        case sword
        case dagger
    }
    
    enum Helmet {
        case wooden
        case iron
        case diamond
    }
    
    case thief(weapon: Weapon, helmet: Helmet)
    case warrior(weapon: Weapon, helmet: Helmet)
    
    func getDescription() -> String {
        switch self {
        case let .thief(weapon, helmet):
            return "Thief chosen \(weapon) and \(helmet) helmet"
        case let .warrior(weapon, helmet):
            return "Warrior chosen \(weapon) and \(helmet) helmet"
        }
    }
}

//3.2  Initialization
let helmet = Character.Helmet.iron
print(helmet)

let weapon = Character.Weapon.dagger
print(weapon)

let character1 = Character.warrior(weapon: .sword, helmet: .diamond)
print(character1.getDescription())

let character2 = Character.thief(weapon: .bow, helmet: .iron)
print(character2.getDescription())



//4. Containing Enums
//4.1 Create a Struct which containing Enums
struct Character1 {
    enum CharacterType {
        case thief
        case warrior
    }
    enum Weapon {
        case bow
        case sword
        case dagger
    }
    let type: CharacterType
    let weapon: Weapon
}

//4.2  Initialization
let character3 = Character1(type: .warrior, weapon: .sword)
print("\(character3.type) chosen \(character3.weapon)")



//5. Mutating Method
enum TriStateSwitch {
    case off
    case low
    case high
    mutating func next() {
        switch self {
        case .off:
            self = .low
        case .low:
            self = .high
        case .high:
            self = .off
        }
    }
}

var ovenLight = TriStateSwitch.off
ovenLight.next()
ovenLight.next()
ovenLight.next()



//6. Static Method
enum Device2 {
    case iPhone
    case iPad
    
    static func getDevice(name: String) -> Device? {
        switch name {
        case "iPhone":
            return .iPhone
        case "iPad":
            return .iPad
        default:
            return nil
        }
    }
}

if let device2 = Device2.getDevice(name: "iPhone") {
    print(device2)
}



//7. Custom Init
enum IntCategory {
    case small
    case medium
    case big
    case weird
    
    init(number: Int) {
        switch number {
        case 0..<1000 :
            self = .small
        case 1000..<100000:
            self = .medium
        case 100000..<1000000:
            self = .big
        default:
            self = .weird
        }
    }
}

let intCategory = IntCategory(number: 34645)
print(intCategory)



//8. Protocol Oriented Enum
//8.1 Create Protocol
protocol LifeSpan {
    var numberOfHearts: Int { get }
    mutating func getAttacked() // heart -1
    mutating func increaseHeart() // heart +1
}

//8.2 Create Enum
enum Player: LifeSpan {
    case dead
    case alive(currentHeart: Int)
    
    var numberOfHearts: Int {
        switch self {
        case .dead: return 0
        case let .alive(numberOfHearts): return numberOfHearts
        }
    }
    
    mutating func increaseHeart() {
        switch self {
        case .dead:
            self = .alive(currentHeart: 1)
        case let .alive(numberOfHearts):
            self = .alive(currentHeart: numberOfHearts + 1)
        }
    }
    
    mutating func getAttacked() {
        switch self {
        case .alive(let numberOfHearts):
            if numberOfHearts == 1 {
                self = .dead
            } else {
                self = .alive(currentHeart: numberOfHearts - 1)
            }
        case .dead:
            break
        }
    }
}

//8.3 Play Game
var player = Player.dead

player.increaseHeart()
print(player.numberOfHearts)

player.increaseHeart()
print(player.numberOfHearts)

player.getAttacked()
print(player.numberOfHearts)

player.getAttacked()
print(player.numberOfHearts)



//9. Extensions
enum Entities {
    case soldier(x: Int, y: Int)
    case tank(x: Int, y: Int)
    case player(x: Int, y: Int)
}

extension Entities {
    mutating func attack() {}
    mutating func move(distance: Float) {}
}

extension Entities: CustomStringConvertible {
    var description: String {
        switch self {
        case let .soldier(x, y): return "Soldier position is (\(x), \(y))"
        case let .tank(x, y): return "Tank position is (\(x), \(y))"
        case let .player(x, y): return "Player position is (\(x), \(y))"
        }
    }
}



//10. Generic Enums
enum Information<T1, T2> {
    case name(T1)
    case website(T1)
    case age(T2)
}


// let info = Information.name("Bob") // Error- Generic parameter 'T2' could not be inferred

let info = Information<String, Int>.age(20)
print(info)



//11. Recursive Enums
indirect enum ArithmeticExpressions {
    case number(Int)
    case addition(ArithmeticExpressions, ArithmeticExpressions)
    case multiplication(ArithmeticExpressions, ArithmeticExpressions)
}

func evaluate(_ expression: ArithmeticExpressions) -> Int {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}


let expression = evaluate(ArithmeticExpressions.addition(.number(1), .number(2)))
print(expression)