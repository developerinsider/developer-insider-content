/* String */

import Foundation


//1.1 Initializing Strings
var name = "Vineeta"
print(name)

print( "Welcome, \(name)!")



//1.2 Initializing Multiline String - beta version
 let banner = """
 __,
 (          o   /) _/_
 `.  , , , ,  //  /
 (___)(_(_/_(_ //_ (__
 /)
 (/
 """
 print(banner)



//1.3 initializing an empty string
var emptyString = ""
var anotherEmptyString = String()
var anotherOneEmptyString: String

let newString = String()



//2.1 Concatenation
let greetMsg =  name + " We're glad you're here!"
print(greetMsg)



//2.2 String Mutability
var variableString = "Horse"
variableString += " and carriage"
print(variableString)



//2.3  Compairing String
let cafe1 = "Cafe\u{301}"
let cafe2 = "Café"
print(cafe1 == cafe2)



//3  Measuring the Length of a String
print(name.characters.count)
print(name.count)
print(name.utf8.count)
print(name.utf16.count)
print(name.unicodeScalars.count)



//4 Inspecting a String - isEmpty
if name.isEmpty{
    print("empty tag ")
}else{
    print("Name: \(name)")
}



//5.1 Changingcase - uppercase
print(name.uppercased())



//5.2 lowercase
print(name.lowercased())



//6.1 Finding Substrings - hasSuffix
var str = "My name is Vineeta"
if str.hasSuffix("Vineeta"){
    print("true")
}else{
    print("false")
}



//6.2 hasPrefix
if str.hasPrefix("My"){
    print("true")
}else{
    print("false")
}



//7.1 Finding Characters - contains
let cast = ["Vivek", "vineet", "vineeta", "akshay"]
print(cast.contains("vineet"))
print(cast.contains("James"))



//7.2 contains(where:)
let expenses = [21.37, 55.21, 9.32, 10.18, 388.77, 11.41]
let hasBigPurchase = expenses.contains { $0 > 100 }
print(hasBigPurchase)



//7.3 first(where:)
let numbers = [3, 7, 4, -2, 9, -6, 10, 1]
if let firstNegative = numbers.first(where: { $0 < 0 }) {
    print("The first negative number is \(firstNegative).")
}



//7.4 index(of:)
var students = ["Akshay", "Vivek", "Vineet", "Vineeta"]
if let i = students.index(of: "Maxime") {
    students[i] = "Max"
}
print(students)



//7.5 index(where:)
if let i = students.index(where: { $0.hasPrefix("A") }) {
    print("\(students[i]) starts with 'A'!")
}



//7.6 max()
let heights = [67.5, 65.7, 64.3, 61.1, 58.5, 60.3, 64.9]
let greatestHeight = heights.max()
print(greatestHeight ?? "nothing in there")



//7.7 max(by:)
let hues = ["Heliotrope": 296, "Coral": 16, "Aquamarine": 156]
let greatestHue = hues.max { a, b in a.value < b.value }
print(greatestHue ?? "nothing")



//8 Appending Strings and Characters - append(_:)
name.insert("a", at:name.startIndex)
print(name)



//9 Inserting Characters - insert(_:at:)
name.insert("a", at:name.startIndex)
print(name)

var numbersArray = [1, 2, 3, 4, 5]
numbersArray.insert(100, at: 3)
numbersArray.insert(200, at: numbersArray.endIndex)
print(numbersArray)



//10.1 Removing Substrings - remove(_:at:)
var nonempty = "non-empty"
if let i = nonempty.characters.index(of: "-") {
    nonempty.remove(at: i)
}
print(nonempty)



//10.2 remove(_:at:_)
var measurements = [1.2, 1.5, 2.9, 1.2, 1.6]
let removed = measurements.remove(at: 2)
print(measurements)



//10.3 removeAll(keepingCapacity:)
let measure = measurements.removeAll()
print(measure)



//10.4 removeFirst()
var bugs = ["Aphid", "Bumblebee", "Cicada", "Damselfly", "Earwig"]
bugs.removeFirst()
print(bugs)



//10.5 removeFirst(_:)
bugs.removeFirst(3)
print(bugs)



//10.6 removeLast()
bugs.removeLast()
print(bugs)



//10.7 removeLast(_:)
bugs = ["Aphid", "Bumblebee", "Cicada", "Damselfly", "Earwig"]
bugs.removeLast(3)
print(bugs)



//10.8 removeSubrange(_:)
measurements = [1.2, 1.5, 2.9, 1.2, 1.6]
measurements.removeSubrange(1..<5)
print(measurements)



//10.9 removeSubrange(_:)
measurements = [1.2, 1.5, 2.9, 1.2, 1.5]
measurements.removeSubrange(1..<4)
print(measurements)



//10.10 filter(_:) - beta version
var cast1 = ["Vivien", "Marlon", "Kim", "Karl"]
let shortNames = cast1.filter { $0.count < 5 }
print(shortNames)



//11.1  Getting Characters and Bytes - subscript(_:) - beta version
let greeting = "Hi there! It's nice to meet you! 👋"
if let i = greeting.characters.index(where: { $0 >= "A" && $0 <= "Z" }) {
    print("First capital letter: \(greeting[i])")
}


//11.2 first
let numbersArr = [10, 20, 30, 40, 50]
if let firstNumber = numbersArr.first {
    print(firstNumber)
}



//11.3 last
if let firstNumber = numbersArr.last {
    print(firstNumber)
}



//12.1 Related String Type - substring - beta version
let endOfSentence = greeting.index(of: "!")!
let firstSentence = greeting[...endOfSentence]
print(firstSentence)



//12.2 Converting a Substring to a String - beta version
let rawInput = "126 a.b 22219 zzzzzz"
let numericPrefix = rawInput.prefix(while: { "0"..."9" ~= $0 })
print(numericPrefix)



// 13.1 Describing a String - description
print(rawInput.description)



//13.2 debugDescription
print(rawInput.debugDescription)



//13.3 customMirror
print(rawInput.customMirror)



//13.4 customPlaygroundQuickLook
print(rawInput.customPlaygroundQuickLook)



//13.5 hashValue
print(rawInput.hashValue)



//14. Creating a Range Expression  ..<(_:)
let numbersGrp = [10, 20, 30, 40, 50, 60, 70]
print(numbersGrp[..<3])



//14.2 ...(_:)
print(numbers[3...])



//14.3 ...(_:)
let number = [10, 20, 30, 40, 50, 60, 70]
print(number[...3])



//15.1 Manipulating Indices - startIndex
print(numbers.startIndex)



//15.2 endIndex
print(numbers.endIndex)



//15.3 index(after:)
print(numbers.index(after: 3))



//15.4 index(_:offsetBy:)
let s = "Swift"
let i = s.index(s.startIndex, offsetBy: 4)
print(s[i])



//15.5 index(_:offsetBy:limitedBy:)
if let i = s.index(s.startIndex, offsetBy: 4, limitedBy: s.endIndex) {
    print(s[i])
}



//15.6 index(before:)
print(numbers.index(before: 3))



//15.7 distance(from:to:)
let numDistance = numbers.distance(from: 0, to: 3)
print(numDistance)


//16.1 Iterating over a String's Characters - forEach(_:)
let numberWords = ["one", "two", "three"]
for word in numberWords {
    print(word)
}
numberWords.forEach { word in
    print(word)
}



//16.2 enumerated() - beta version
for (n, c) in "Swift".enumerated() {
    print("\(n): '\(c)'")
}



//17.1 Sorting a String's Characters - sorted()
let sortedStudents = students.sorted()
print(sortedStudents)



//17.2 sorted(by:)
let descendingStudents = students.sorted(by: >)
print(descendingStudents)



//17.3 reversed()
let word = "Backwards"
for char in word.reversed() {
    print(char, terminator: "")
}



//18.1 Working with String Views - characters
let newStr = "vivek kumar tyagi"
    print(newStr.characters.count)



//18.2 init(_:)
let poem = """
'Twas brillig, and the slithy toves /
Did gyre and gimbal in the wabe: /
All mimsy were the borogoves /
And the mome raths outgrabe.
"""
let excerpt = String(poem.characters.prefix(22)) + "..."
print(excerpt)



//18.3 withMutableCharacters(_:)
let afterSpace = str.withMutableCharacters { chars -> String.CharacterView in
    if let i = chars.index(of: " ") {
        let result = chars[chars.index(after: i)...]
        chars.removeSubrange(i...)
        return result
    }
    return String.CharacterView()
}
print(str)
print(String(afterSpace))



//18.4 unicodeScalars
for char in word.unicodeScalars{
    print(char)
}



//18.5 init(_:)
let picnicGuest = "Deserving porcupine"
if let i = picnicGuest.unicodeScalars.index(of: " ") {
    let adjective = String(picnicGuest.unicodeScalars[..<i])
    print(adjective)
}



//18.6 utf16
print(picnicGuest.utf16.count)



//18.7 utf8
print(picnicGuest.utf8.count)



//19. Transforming a String's Characters - map(_:)
let lowercaseNames = cast.map { print($0.lowercased()) }
let letterCounts = cast.map { print($0.characters.count) }



//19.2 reduce(_:_:)
let numberSum = print(numbers.reduce(0, { x, y in
    x + y
}))



//20. Getting C Strings - utf8CString
let bytes = s.utf8CString
print(bytes)
