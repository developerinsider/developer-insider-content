//1.1 init()
let x: Double = 21.25
let y = Float(x)
print(y)



//1.2 init(signOf:magnitudeOf:)
var a = -21.5
let b = 305.15
let c = Double(signOf: a, magnitudeOf: b)
print(c)



//1.3 init(sign:exponent:significand:)
let z = Double(sign: .plus, exponent: -2, significand: 1.5)
print(z)



//2.1 Performing Calculations
print(a + b)

print(a - b)

print(a * b)

print(a / b)

a += b
print(a)

a -= b
print(a)

a *= b
print(a)

a /= b
print(a)



//2.2 squareRoot()
func hypotenuse(_ a: Double, _ b: Double) -> Double {
    return (a * a + b * b).squareRoot()
}

let (dx, dy) = (3.0, 4.0)
let distance = hypotenuse(dx, dy)
print(distance)



//2.3 remainder(dividingBy:)
let q = (x / 0.75).rounded(.toNearestOrEven)
let r = x.remainder(dividingBy: 0.75)
print(q,r)



//2.4 negate()
var k = 21
k.negate()
print(k)



//3.1 rounded()
let m = 6.5
print(m.rounded(.toNearestOrAwayFromZero))
print(m.rounded(.towardZero))
print(m.rounded(.up))
print(m.rounded(.down))



//3.2 round
var j = 5.2
j.round()
print(j)

var h = 5.5
h.round()
print(h)

var g = -5.5
g.round()
print(g)



//4.1 comparison
print(a > b)

print(a < b)

print(a <= b)

print(a >= b)

print(a == b)



//4.2 maximum(_:_:)
print(Double.maximum(10.0, -25.0))



//4.2 minimum(_:_:)
print(Double.minimum(10.0, -25.0))



//5.1 magnitude
let num1 = -259.0001
print(num1.magnitude)



//5.2 sign
print(num1.sign)



//6.1 ulp
let num2 = 0.23
print(num2.ulp)



//6.2 significand
let num3 = 9.91
print(num3.significand)



//6.3 exponent
print(num3.exponent)



//6.4 nextUp
let num4 = 10.0
print(num4.nextUp)



//6.5 nextDown
print(num4.nextDown)



//6.6 binade
print(num4.binade)



//7.1 pi
print(Double.pi)



//7.2 infinity
let x1 = Double.greatestFiniteMagnitude
let y1 = x1 * 2
print(y1)



//7.3 greatestFiniteMagnitude
print(x1)



//7.4 nan
print(x1 > Double.nan)



//7.5 signalingNaN
print(x1 > Double.signalingNaN)



//7.6 ulpOfOne
print(x1 > Double.ulpOfOne)



//7.7 leastNormalMagnitude
print (x1 < Double.leastNormalMagnitude)



//7.8 leastNonzeroMagnitude
print(Double.leastNonzeroMagnitude)



//8.1 bitPattern
let num5 = 3000.00
print(num5.bitPattern)



//8.2 significandBitPattern
print(num5.significandBitPattern)



//8.3 exponentBitPattern
print(num5.exponentBitPattern)



//8.4 significandWidth
print(num5.significandWidth)



//9.1 isZero
print(num5.isZero)



//9.2 isSubnormal
print(num5.isSubnormal)



//10.1 description
print(num5.description)



//10.2 debugDescription
print(num5.debugDescription)



//10.3 customMirror
print(num5.customMirror)



//10.4 hashValue
print(num5.hashValue)
