//: Playground - noun: a place where people can play

//1. Instance methods

class Counter {
    var count = 0
    func increment() {
        count += 1
        print("value of count in increment() func is ",count)
    }
    func increment(by amount: Int) {
        count += amount
        print("value of count in increment(by:) func is ",count)
    }
    func reset() {
        count = 0
        print("value of count in reset func is ",count)
    }
}
let counter = Counter()
counter.increment()
counter.increment(by: 5)
counter.reset()


//1.1 The self property

class Calculations {
    let a: Int
    let b: Int
    let res: Int
    
    init(a: Int, b: Int) {
        self.a = a
        self.b = b
        res = a + b
        print("Inside Self Block: \(res)")
    }
    
    func tot(c: Int) -> Int {
        return res - c
    }
    
    func result() {
        print("Result is: \(tot(c: 20))")
        print("Result is: \(tot(c: 50))")
    }
}

let pri = Calculations(a: 600, b: 300)
let sum = Calculations(a: 1200, b: 300)

pri.result()
sum.result()


// 1.2 Modifying Value Types from Instance Methods

struct area {
    var length = 1
    var breadth = 1
    
    func area() -> Int {
        return length * breadth
    }
    mutating func scaleBy(res: Int) {
        length *= res
        breadth *= res
        print(length)
        print(breadth)
    }
}

var val = area(length: 3, breadth: 5)
val.scaleBy(res: 3)
val.scaleBy(res: 30)
val.scaleBy(res: 300)

// 1.3 Assigning to self within a mutating method

struct Area {
    var length = 1
    var breadth = 1
    func area() -> Int {
        return length * breadth
    }
    mutating func scaleBy(res: Int) {
        self.length *= res
        self.breadth *= res
        print(length)
        print(breadth)
    }
}

var val1 = Area(length: 3, breadth: 5)
val1.scaleBy(res: 13)

//2. Type method

class Math {
    class func abs(number: Int) -> Int {
        if number < 0 {
            return (-number)
        } else {
            return number
        }
    }
}

struct absno {
    static func abs(number: Int) -> Int {
        if number < 0 {
            return (-number)
        } else {
            return number
        }
    }
}

let no = Math.abs(number: -35)
let num = absno.abs(number: -5)

print(no)
print(num)
