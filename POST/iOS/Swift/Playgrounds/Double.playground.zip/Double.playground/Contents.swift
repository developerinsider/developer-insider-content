//1.1 Converting Floating-Point Values -init()
let x: Double = 21.25
let y = Double(x)
print(x, y)

//1.2 init(sign:exponent:significand:)
let z = Double(sign: .plus, exponent: -2, significand: 1.5)
print(z)

//1.3 init(signOf:magnitudeOf:)
var a = -21.5
let b = 305.15
let c = Double(signOf: a, magnitudeOf: b)
print(c)



//2.1  Floating-Point Operators for Double
print(a + b)

print(a - b)

print(a * b)

print(a / b)

a += b
print(a)

a -= b
print(a)

a *= b
print(a)

a /= b
print(a)

//2.2 squareRoot()
func hypotenuse(_ a: Double, _ b: Double) -> Double {
    return (a * a + b * b).squareRoot()
}

let (dx, dy) = (3.0, 4.0)
let distance = hypotenuse(dx, dy)
print(distance)

//2.3 remainder(dividingBy:)
let q = (x / 0.75).rounded(.toNearestOrEven)
let r = x.remainder(dividingBy: 0.75)
print(q,r)

//2.4  negate()
var k = 21.003
k.negate()
print(k)



//3.1 Querying a Double's State - isZero
let m = -0.0
print(m.isZero)

//3.2 isFinite
print(m.isFinite)

//3.3 isInfinite
print(m.isInfinite)

//3.4 isNaN
let x1 = 0.0
let y1 = x1 * .infinity
print(x1 == Double.nan)
print(y1 == Double.nan)

//3.5 isSignalingNaN
print(x1.isSignalingNaN)
print(y1.isSignalingNaN)

//3.6 isNormal
print(x1.isNormal)
print(y1.isNormal)

//3.7 isSubnormal
print(x1.isSubnormal)
print(y1.isSubnormal)

//3.8 isCanonical
print(x1.isCanonical)
print(y1.isCanonical)

//3.9 floatingPointClass
print(x1.floatingPointClass)
print(y1.floatingPointClass)



//4.1  rounded()
let m1: Double = 6.5
print(m1.rounded(.toNearestOrAwayFromZero))
print(m1.rounded(.towardZero))
print(m1.rounded(.up))
print(m1.rounded(.down))

//4.2 round()
var j = 5.2
j.round()
print(j)

var h = 5.5
h.round()
print(h)

var g = -5.5
g.round()
print(g)

//5.1 comparison
print(a > b)
print(a < b)
print(a <= b)
print(a >= b)
print(a == b)

//5.2 isEqual(to:)
if(a.isEqual(to: b)){
    print(a)
}else{
    print(b)
}

//5.3 isLess(than:)
if(a.isLess(than: b)){
    print(a)
}else{
    print(b)
}

//5.4 isLessThanOrEqualTo(_:)
if(a.isLessThanOrEqualTo(b)){
    print(a)
}else{
    print(b)
}

//5.5 isTotallyOrdered(belowOrEqualTo:)
if(a.isTotallyOrdered(belowOrEqualTo: b)){
    print(a)
}else{
    print(b)
}

//5.6 minimum(_:_:)
print(Double.minimum(10.0, -25.0))

//5.7 maximum(_:_:)
print(Double.maximum(10.0, -25.0))

//5.8 minimumMagnitude(_:_:)
print(Double.minimumMagnitude(-10.0, 2.0))

//5.9 maximumMagnitude(_:_:)
print(Double.maximumMagnitude(-10.0, 2.0))



//6.1 magnitude
let num1 = -259.0001
print(num1.magnitude)

//6.2 sign
print(num1.sign)



//7.1 ulp
let num2 = 0.23
print(num2.ulp)

//7.2 significand
let num3 = 9.91
print(num3.significand)

//7.3 exponent
print(num3.exponent)

//7.4 nextUp
let num4 = 10.0
print(num4.nextUp)

//7.5 nextDown
print(num4.nextDown)

//7.6 binade
print(num4.binade)



//8.1 pi
print(Double.pi)

//8.2 infinity
print(y1)

//8.3 greatestFiniteMagnitude
print(x1)

//8.4 nan
print(x1 > Double.nan)

//8.5 signalingNaN
print(x1 > Double.signalingNaN)

//8.6 ulpOfOne
print(x1 > Double.ulpOfOne)



//9.1 bitPattern
let num5 = 3000.00
print(num5.bitPattern)

//9.2 significandBitPattern
print(num5.significandBitPattern)

//9.3 exponentBitPattern
print(num5.exponentBitPattern)

//9.4 significandWidth
print(num5.significandWidth)



//10.1 description
print(num5.description)

//10.2 debugDescription
print(num5.debugDescription)

//10.3 customMirror
print(num5.customMirror)

//10.4 hashValue
print(num5.hashValue)



//11.1 distance(to:)
let x2 = 21.5
let d2 = x2.distance(to: 15.0)
print(d2)

//11.2 advanced(by:)
print(x2.advanced(by: d2))

//11.3 init(floatLiteral:)
let x3: Double = 21.25
print(x3)
