
// structure definition, instance and accessing

struct Resolution {
    var width = 0
    var height = 0
}
let someResolution = Resolution()
print("The width of someResolution is \(someResolution.width)")
print("The height of someResolution is \(someResolution.height)")

class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}
let someVideoMode = VideoMode()
someVideoMode.resolution.width = 1280
print("The width of someVideoMode is now \(someVideoMode.resolution.width)")


// Memberwise Initializers for Structure Types

let vga = Resolution(width: 640, height: 480)
print(vga.width)
print(vga.height)


// Structures and Enumerations Are Value Types

let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
cinema.width = 2048
print("value of width is changed in cinema:",cinema.width)
print("value of width in hd is still the same as earlier",hd.width)

enum CompassPoint {
    case north, south, east, west
}
var currentDirection = CompassPoint.west
let rememberedDirection = currentDirection
currentDirection = .east
print("The current direction is changed to", currentDirection)
if rememberedDirection == .west {
    print("But the remembered direction is still",rememberedDirection)
}


// classes are reference type
    
let tenEighty = VideoMode()

print("values in videoMode of tenEighty.frameRate,tenEighty.resolution.height,tenEighty.resolution.width,tenEighty.name,tenEighty.frameRate are",tenEighty.frameRate,tenEighty.resolution.height,tenEighty.resolution.width,tenEighty.name ?? "enter name",tenEighty.frameRate)

tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

print("values in videoMode of tenEighty.frameRate,tenEighty.resolution.height,tenEighty.resolution.width,tenEighty.name,tenEighty.frameRate are",tenEighty.frameRate,tenEighty.resolution.height,tenEighty.resolution.width,tenEighty.name ?? "changed",tenEighty.frameRate)
print("value of framerate before assigning to new variable:",tenEighty.frameRate)

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0

print("value of framearate changed in new instance and reflected at their reference :",tenEighty.frameRate)

// Identity Operators

if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
}else{
    print("different instances")
}
