import UIKit

//1. For loop with Half-open range
//1.1 With Half-open range operator
let names = ["Anna", "Alex", "Brian", "Jack"]
for name in names[..<2] {
    print(name)
}
/* prints -
 Anna
 Alex */

for name in names[1..<3] {
    print(name)
}
/* prints -
 Alex
 Brian
 */

//1.2 Without Half-open range operator
for (index, name) in names.enumerated(){
    if index < 2 {
        print(name)
    }
}
/* prints -
 Anna
 Alex */

//with while loop
var index = 0
while index < 2 {
    print(names[index])
    index += 1
}
/* prints -
 Anna
 Alex */

//2. For loop with Closed range
//2.1 With Closed range operator
for name in names[...2] {
    print(name)
}
/* prints -
 Anna
 Alex
 Brian
 */

for name in names[1...2] {
    print(name)
}
/* prints -
 Alex
 Brian
 */

//2.2 Without Closed range operator
for (index, name) in names.enumerated(){
    if index >= 1 && index <= 2 {
        print(name)
    }
}
/* prints -
 Alex
 Brian
 */

//3. Subscripts
//3.1 Without Subscripts (or 💩 Code)
//struct Matrix {
//    let rows: Int, columns: Int
//    var grid: [Double]
//    init(rows: Int, columns: Int) {
//        self.rows = rows
//        self.columns = columns
//        self.grid = Array(repeatElement(0.0, count: rows * columns))
//    }
//
//    func getValue(row: Int, column: Int) -> Double{
//        return grid[(row * columns) + column]
//    }
//
//    mutating func setValue(row: Int, column: Int, value: Double){
//        grid[(row * columns) + column] = value
//    }
//}
//
//var matrix = Matrix(rows: 2, columns: 2)
//matrix.setValue(row: 0, column: 0, value: 1.0)
//matrix.setValue(row: 0, column: 1, value: 2.0)
//matrix.setValue(row: 1, column: 0, value: 3.0)
//matrix.setValue(row: 1, column: 1, value: 4.0)
//
//print(matrix.getValue(row: 0, column: 0)) //prints "1.0"
//print(matrix.getValue(row: 0, column: 1)) //prints "2.0"
//print(matrix.getValue(row: 1, column: 0)) //prints "3.0"
//print(matrix.getValue(row: 1, column: 1)) //prints "4.0"

//3.2 With Subscripts (or ❤️ Code)
struct Matrix {
    let rows: Int, columns: Int
    var grid: [Double]
    init(rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        self.grid = Array(repeatElement(0.0, count: rows * columns))
    }
    subscript(row: Int, column: Int) -> Double {
        get {
            return grid[(row * columns) + column]
        }
        set {
            grid[(row * columns) + column] = newValue
        }
    }
}

var matrix = Matrix(rows: 2, columns: 2)

matrix[0,0] = 1.0
matrix[0,1] = 2.0
matrix[1,0] = 3.0
matrix[1,1] = 4.0

print(matrix[0,0]) //prints "1.0"
print(matrix[0,1]) //prints "2.0"
print(matrix[1,0]) //prints "3.0"
print(matrix[1,1]) //prints "4.0"



//4. Function vs Computed Property
//4.1 Function (or 💩 Code)
func getDiameter(radius: Double) -> Double {
    return radius * 2
}

func getRadius(diameter: Double) -> Double {
    return diameter / 2
}

print(getDiameter(radius: 100)) //prints "200"
print(getRadius(diameter: 100)) //prints "50"

//4.2 Computed Property (or ❤️ Code)
var radius: Double = 100
var diameter: Double {
    get {
        return radius * 2
    }
    set {
        radius = newValue / 2
    }
}

print(diameter) //prints "200.0"
diameter = 100
print(radius) //prints "50.0"



//5. Extension
//5.1 Without Extensions (or 💩 Code)
func centimeterToMeter(value: Double) -> Double{
    return value / 100.0
}

func kilometerToMeter(value: Double) -> Double{
    return value * 1000.0;
}

let thousandCentimeter = 1000.0
print("Thousand centimeter is \(centimeterToMeter(value: thousandCentimeter)) meters")
// Prints "Thousand centimeter is 10.0 meters"

let threeKilometer  = 3.0
print("Three km is \(kilometerToMeter(value: threeKilometer)) meters")
// Prints "Three km is 3000.0 meters"

//5.2 With Extensions (or ❤️ Code)
//extension Double {
//    var m: Double { return self }
//    var km: Double { return self * 1000.0 }
//    var cm: Double { return self / 100.0 }
//    var mm: Double { return self / 1000.0 }
//}
//
//let thousandCentimeter = 1000.cm
//print("Thousand centimeter is \(thousandCentimeter) meters")
//// Prints "Thousand centimeter is 10.0 meters"
//
//let threeKilometer  = 3.km
//print("Three km is \(threeKilometer) meters")
//// Prints "Three km is 3000.0 meters"



//6. Ternary conditional
//6.1 With ternary coditional operator (or ❤️ Code)
let contentHeight = 40
let hasHeader = true
let rowHeight = contentHeight + (hasHeader ? 50 : 20)
print(rowHeight) //prints "90"

//6.2 Without ternary coditional operator (or 💩 Code)
var rowHeight1: Int
if hasHeader == true {
    rowHeight1 = contentHeight + 50
} else {
    rowHeight1 = contentHeight + 20
}
print(rowHeight1) //prints "90"


//7 Nil coalescing
//7.1 Nil coalescing  (or 😎 Code)
let defaultColorName = "red"
var userDefinedColorName: String?   // defaults to nil

var colorNameToUse = userDefinedColorName ?? defaultColorName
print(colorNameToUse)  //prints "red"
// userDefinedColorName is nil, so colorNameToUse is set to the default of "red"

userDefinedColorName = "green"
colorNameToUse = userDefinedColorName ?? defaultColorName
print(colorNameToUse)  //prints "green"
// Now userDefinedColorName is "green", so colorNameToUse is set to the value of userDefinedColorName of "green"

//7.2 Without Nil coalescing  (or 💩 Code)
var colorNameToUse1: String!
if let color = userDefinedColorName {
    colorNameToUse1 = color
} else {
    colorNameToUse1 = defaultColorName
}
print(colorNameToUse1) //prints "green"
//userDefinedColorName is "green", so colorNameToUse is set to the value of userDefinedColorName of "green"



//8. Optional Unwrapping (if let vs guard let)
let emailField = UITextField()
emailField.text = "abcd@mail.com"
let usernameField = UITextField()
usernameField.text = "vineet"
let passwordField = UITextField()
passwordField.text = "123456"
let conifrmPasswordField = UITextField()
conifrmPasswordField.text = "123456"

//8.1 if let (or Bad Code)
func loginIfLet(){
    if let email = emailField.text {
        if let username = usernameField.text {
            if let password = passwordField.text {
                if let conifrmPassword = conifrmPasswordField.text {
                    if password == conifrmPassword {
                        print("Email - \(email)")
                        print("Username - \(username)")
                        print("Password - \(password)")
                    } else {
                        print("Password didn't match with conifrm password.")
                    }
                } else {
                    print("Conifrm password is empty.")
                }
            } else {
                print("Password is empty.")
            }
        } else {
            print("Username is empty.")
        }
    } else {
        print("Email is empty.")
    }
}
loginIfLet()


//8.2 guard let (or Awesome Code)
func loginGuardLet(){
    guard let email = emailField.text else {
        print("Email is empty.")
        return
    }
    guard let username = usernameField.text else {
        print("Username is empty.")
        return
    }
    guard let password = passwordField.text else {
        print("Password is empty.")
        return
    }
    guard let conifrmPassword = conifrmPasswordField.text else {
        print("Conifrm password is empty.")
        return
    }
    if password == conifrmPassword {
        print("Email - \(email)")
        print("Username - \(username)")
        print("Password - \(password)")
    } else {
        print("Password didn't match with conifrm password.")
    }
}
loginGuardLet()


//9. Functional Programming
//9.1 Old Approach (or Bad Code)
var evenNumbers = [Int]()
for number in 1...10 {
    if number % 2 == 0 {
        evenNumbers.append(number)
    }
}
print(evenNumbers) //prints "[2, 4, 6, 8, 10]"

//9.2 Modern Approach (or Good Code)
var evens = Array(1...10).filter { (num) -> Bool in
    return num % 2 == 0
}
print(evens) //prints "[2, 4, 6, 8, 10]"

evens = Array(1...10).filter { $0 % 2 == 0}
print(evens) //prints "[2, 4, 6, 8, 10]"



//10. Generics
//10.1  Without Generics (or 💩 Code)
func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}

func swapTwoStrings(_ a: inout String, _ b: inout String) {
    let temporaryA = a
    a = b
    b = temporaryA
}

var someInt = 3
var anotherInt = 107
swapTwoInts(&someInt, &anotherInt)
print("someInt = \(someInt)")
print("anotherInt = \(anotherInt)")
/* prints
 someInt = 107
 anotherInt = 3
 */

var someString = "hello"
var anotherString = "world"
swapTwoStrings(&someString, &anotherString)
print("someString = \(someString)")
print("anotherString = \(anotherString)")
/* prints
 someString = world
 anotherString = hello
 */

//10.2 With Generics  (or 👊 Code)

func swapTwoValues<T>(_ a: inout T, _ b: inout T) {
    let temporaryA = a
    a = b
    b = temporaryA
}

someInt = 3
anotherInt = 107
swapTwoValues(&someInt, &anotherInt)
print("someInt = \(someInt)")
print("anotherInt = \(anotherInt)")
/* prints
 someInt = 107
 anotherInt = 3
 */

someString = "hello"
anotherString = "world"
swapTwoValues(&someString, &anotherString)
print("someString = \(someString)")
print("anotherString = \(anotherString)")
/* prints
 someString = world
 anotherString = hello
 */

//11. Type safe using Enum (enumeration)
//11.1 Without Enum (or 💩 Code)
let directionToHead = "east"
switch directionToHead {
case "north":
    print("Lots of planets have a north")
case "south":
    print("Watch out for penguins")
case "east":
    print("Where the sun rises")
case "west":
    print("Where the skies are blue")
default:
    print("Unknown direction")
}
//prints "Where the sun rises"

//11.2 With Enum (or 👊 Code)
enum CompassPoint {
    case north, south, east, west
}
let direction: CompassPoint = .east

switch direction {
case .north:
    print("Lots of planets have a north")
case .south:
    print("Watch out for penguins")
case .east:
    print("Where the sun rises")
case .west:
    print("Where the skies are blue")
}
//prints "Where the sun rises"
