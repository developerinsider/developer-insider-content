import Foundation

//1. Prefix operators

//1.1 Logical NOT (!)
let allowedEntry = false
if !allowedEntry {
    print("ACCESS DENIED")
}

//1.2 Bitwise NOT (~)
let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits  //equals 11110000
print(invertedBits)

//1.3 Unary plus (+)
let minusSix = -6
let alsoMinusSix = +minusSix
print(alsoMinusSix)

//1.4 Unary minus (-)
let three = 3
let minusThree = -three
print(minusThree)

let plusThree = -minusThree
print(plusThree)

//1.5 Half-open range (..<)
let names = ["Anna", "Alex", "Brian", "Jack"]
for name in names[..<2] {
    print(name)
}

//1.6 Closed range (...)
for name in names[...2] {
    print(name)
}





//2. Postfix operators
//2.1 Closed range
for name in names[2...] {
    print(name)
}




//3. Infix operators
//3.1 Bitwise left shift (<<)
let shiftBits: UInt8 = 4   //00000100 in binary
shiftBits << 1             //00001000
shiftBits << 2             //00010000
shiftBits << 5             //10000000
shiftBits << 6             //00000000

//3.2 Bitwise right shift (>>)
shiftBits >> 1             //00000010
shiftBits >> 2             //00000001
shiftBits >> 3             //00000000

//3.3 Add (+)
let num1 = 10
let num2 = 2
let addition = num1 + num2
print(addition)

//3.4 Subtract (-)
let subtraction = num1 - num2
print(subtraction)

//3.5 Multiply (*)
let multiplication = num1 * num2
print(multiplication)

//3.6 Divide (/)
let division = num1 / num2
print(division)

//3.7 Remainder (%)
let remainder = num1 % num2
print(remainder)

//3.8 Add with overflow (&+)
var potentialOverflow = Int16.max //potentialOverflow equals 32767, which is the maximum value a Int16 can hold
//potentialOverflow = potentialOverflow + 1 //this causes an error

var int16Overflow = Int16.max
int16Overflow = int16Overflow &+ 1
print(int16Overflow)

//3.9 Subtract with overflow (&-)
int16Overflow = Int16.min //potentialOverflow equals -32768, which is the minimum value a Int16 can hold
int16Overflow = int16Overflow &- 1
print(int16Overflow)

//3.10 Multiply, ignoring overflow (&*)
int16Overflow = Int16.max
int16Overflow = int16Overflow & 2
print(int16Overflow)

//3.11 Bitwise AND (&)
let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8  = 0b00111111
let middleFourBits = firstSixBits & lastSixBits
print(middleFourBits) //60 = 00111100 in binary

//3.12 Bitwise OR (|)
let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedbits = someBits | moreBits
print(combinedbits) //254 = 11111110 in binary

//3.13 Bitwise XOR (^)
let firstBits: UInt8 = 0b00010100
let otherBits: UInt8 = 0b00000101
let outputBits = firstBits ^ otherBits
print(outputBits) //17 = 00010001

//3.14 Half-open range (..<)
let count = names.count
for i in 0..<count {
    print("Person \(i + 1) is called \(names[i])")
}

//3.15 Closed range (...)
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}


//3.16 Type check (is)
let number = 1
let isNumberInt = number is Int
let isNumberFloat = number is Float
print(isNumberInt)
print(isNumberFloat)

//3.17 Type cast (as, as?, and as!)
let randomObjectsArray: [Any] = [1, 1.2, "Hello", true, [1, 2, 3], "World!"]
for object in randomObjectsArray {
    if let stringObject = object as? String {
        print(stringObject)
    }
}

let randomIntArray: [Any] = [1, 2, 3, 4, 5]
for object in randomIntArray {
    let intObject = object as! Int
    print(intObject)
}

//3.18 Nil coalescing (??)
let defaultColorName = "red"
var userDefinedColorName: String?   // defaults to nil

var colorNameToUse = userDefinedColorName ?? defaultColorName
print(colorNameToUse)
// userDefinedColorName is nil, so colorNameToUse is set to the default of "red"

userDefinedColorName = "green"
colorNameToUse = userDefinedColorName ?? defaultColorName
print(colorNameToUse)

//3.19 Ternary conditional (?:)
let contentHeight = 40
let hasHeader = true
let rowHeight = contentHeight + (hasHeader ? 50 : 20)
print(rowHeight)

//3.20 Less than (<)
let isOneLessThanTwo = (1 < 2)
print(isOneLessThanTwo)

//3.21 Less than or equal (<=)
let isOneLessThanOrEqualToOne = (1 <= 1)
print(isOneLessThanOrEqualToOne)

//3.22 Greater than (>)
let isOneGreaterThanTwo = (1 > 2)
print(isOneGreaterThanTwo)


//3.23 Greater than or equal (>=)
let isOneGreaterThanOrEqualToTwo = (1 >= 2)
print(isOneGreaterThanOrEqualToTwo)

//3.24 Equal (==)
let isOneEqualToTwo = (1 == 2)
print(isOneEqualToTwo)

//3.25 Not equal (!=)
let isOneNotEqualToTwo = (1 != 2)
print(isOneNotEqualToTwo)

//3.26 Identical (===)
let object1 = NSObject()
let object2 = NSObject()
let object3 = object1
let object1IsIdenticalToObject3 = (object1 === object3)
print(object1IsIdenticalToObject3)

//3.27 Not identical (!==)
let object1IsNotIdebticalToObject2 = (object1 !== object2)
print(object1IsNotIdebticalToObject2)

//3.28 Pattern match (~=)
struct Person {
    let name : String
}

// Function that should return true if value matches against pattern
func ~=(pattern: String, value: Person) -> Bool {
    return value.name == pattern
}

let p = Person(name: "Vineet")
switch p {
// This will call our custom ~= implementation, all done through type inference
case "Vineet":
    print("Hey it's me!")
default:
    print("Not me")
}

if case "Vineet" = p {
    print("It's still me!")
}

//3.29 Logical AND (&&)
let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

//3.30 Logical OR (||)
let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

//3.31 Assign (=)
let b = 5
var a = 10
a = b
print(a)

//3.32 Multiply and assign (*=)
a = 10
a *= b
print(a)

//3.33 Divide and assign (/=)
a = 10
a /= b
print(a)

//3.34 Remainder and assign (%=)
a = 10
a %= b
print(a)

//3.35 Add and assign (+=)
a = 10
a += b
print(a)

//3.36 Subtract and assign (-=)
a = 10
a -= b
print(a)

//3.37 Left bit shift and assign (<<=)
var shiftBitsAndAssign: UInt8 = 4   //00000100 in binary
shiftBitsAndAssign <<= 1             //00001000
shiftBitsAndAssign <<= 2             //00100000

//3.38 Right bit shift and assign (>>=)
shiftBitsAndAssign >>= 1             //00010000
shiftBitsAndAssign >>= 2             //00000100

//3.39 Bitwise AND and assign (&=)
var num1Bits: UInt8 = 0b11111100
let num2Bits: UInt8  = 0b00111111
num1Bits &= num2Bits
print(num1Bits)

//3.40 Bitwise OR and assign (|=)
num1Bits = 0b11111100
num1Bits |= num2Bits
print(num1Bits)

//3.41 Bitwise OR and assign (^=)
num1Bits = 0b11111100
num1Bits ^= num2Bits
print(num1Bits)
