//1.1 creating a set - init()

var emptySet = Set<Int>()
print(emptySet.isEmpty)

emptySet = []
print(emptySet.isEmpty)



//1.2 init(minimumCapacity:)

var emptySetWithCapacity = Set<Int>(minimumCapacity: 10)
print(emptySetWithCapacity.capacity)



//1.3  init(_:)

let validIndices = Set(0..<7).subtracting([2, 4, 5])
print(validIndices)



//2.1 isEmpty

print(emptySet.isEmpty)



//2.2 count

print(validIndices.count)



//2.3 first

let numbers = [10, 20, 30, 40, 50]
if let firstNumber = numbers.first {
    print(firstNumber)
}



//2.4 capacity

print(validIndices.capacity)


//3. Testing for Membership - contains(_:)

if (validIndices.contains(3)){
    print("value is there in set")
}



//4.1 Adding Elements - insert(_:)

enum DayOfTheWeek: Int {
    case sunday, monday, tuesday, wednesday, thursday,
    friday, saturday
}

var classDays: Set<DayOfTheWeek> = [.wednesday, .friday]
print(classDays.insert(.monday))
print(classDays)


//4.2 update(with:)

print(classDays.update(with: .monday)  ?? "Default")


//5.1 Removing Elements - filter(_:)

let cast: Set = ["Vivien", "Marlon", "Kim", "Karl"]
let shortNames = cast.filter { $0.count < 5 }
print(shortNames)
print(shortNames.contains("Vivien"))



// 5.2 remove(_:)

var ingredients: Set = ["cocoa beans", "sugar", "cocoa butter", "salt"]
let toRemove = "sugar"
if let removed = ingredients.remove(toRemove) {
    print("The recipe is now \(removed)-free.")
}



// 5.3 removeFirst()

print("set removes \(ingredients.removeFirst())")



// 5.4 removeAll(keepingCapacity:)

ingredients.removeAll(keepingCapacity: false)
print(ingredients)




// 6. Combining Sets - union(_:)

var attendees: Set = ["Alicia", "Bethany", "Diana"]
let visitors = ["Marcia", "Nathaniel"]
let attendeesAndVisitors = attendees.union(visitors)
print(attendeesAndVisitors)




// 6.2 formUnion(_:)

attendees.formUnion(visitors)
print(attendees)




//6.3 intersection(_:)

var employees: Set = ["Alicia", "Bethany", "Chris", "Diana", "Eric"]
var neighbors: Set = ["Bethany", "Eric", "Forlani", "Greta"]
let bothNeighborsAndEmployees = employees.intersection(neighbors)
print(bothNeighborsAndEmployees)




// 6.4 formIntersection(_:)


employees.formIntersection(neighbors)
print(employees)



// 6.5 symmetricDifference(_:)

let eitherNeighborsOrEmployees = employees.symmetricDifference(neighbors)
print(eitherNeighborsOrEmployees)



//6.6 formSymmetricDifference(_:)

employees.formSymmetricDifference(neighbors)
print(employees)




//6.7 subtract(_:)

employees.subtract(neighbors)
print(employees)



//6.8 subtracting(_:)

let nonNeighbors = employees.subtracting(neighbors)
print(nonNeighbors)




//7.1 Comparing Sets - ==(_:_:)

if(employees == neighbors){
    print("All neighbours work together ")
}else{
    print ("set din't match")
}




// 7.2 !=(_:_:)

if(employees != neighbors){
    print("All employees do not live together ")
}else{
    print ("employees are neighbours")
}




// 7.3 isSubset(of:)

print(attendees.isSubset(of: employees))



//7.4 isStrictSubset(of:)

print(attendees.isStrictSubset(of: employees))



//7.5 isSuperset(of:)

print(employees.isSuperset(of: attendees))



//7.6 isStrictSuperset(of:)

print(employees.isStrictSuperset(of: attendees))


//7.7 isDisjoint(with:)

print(employees.isDisjoint(with: visitors))



//8.1 Finding Elements -contains(where:)

enum HTTPResponse {
    case ok
    case error(Int)
}

let lastThreeResponses: [HTTPResponse] = [.ok, .ok, .error(404)]
let hadError = lastThreeResponses.contains { element in
    if case .error = element {
        return true
    } else {
        return false
    }
}
print(hadError)



//8.2 first(where:)


if let firstNegative = numbers.first(where: { $0 < 0 }) {
    print("The first negative number is \(firstNegative).")
}



//8.3 index(of:)

print(numbers.index(of: 4) ?? "default")



//8.4 min()

let heights = [67.5, 65.7, 64.3, 61.1, 58.5, 60.3, 64.9]
let lowestHeight = heights.min()
print(lowestHeight!)


//8.5 min(by:)

let hues = ["Heliotrope": 296, "Coral": 16, "Aquamarine": 156]
let leastHue = hues.min { a, b in a.value < b.value }
print(leastHue ?? "defaultvalue")



//8.6 max(_:)

let greatestHeight = heights.max()
print(greatestHeight ?? "default")



//8.7 max(by:)

let greatestHue = hues.max { a, b in a.value < b.value }
print(greatestHue ?? "defaultValue")



//9.1 enumerated()

for (n, c) in "Swift".enumerated() {
    print("\(n): '\(c)'")
}



//9.2 forEach

let numberWords = ["one", "two", "three"]
for word in numberWords {
    print(word)
}
numberWords.forEach { word in
    print(word)
}


//10.1 description

var numberWord : Set = ["one", "two", "three", "one"]
print(numberWord.description)



//10.2 debugDescription

print(numberWord.debugDescription)



//10.3 customMirror

print(numberWord.customMirror)




//10.4 hashValue

print(numberWord.hashValue)


