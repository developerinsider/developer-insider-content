//1.1 Creating an array

let oddNumbers = [1, 3, 5, 7, 9, 11, 13, 15]
print(oddNumbers)

let streets = ["Albemarle", "Brandywine", "Chesapeake"]
print(streets)



// 1.2 init(repeating:count:)

let fiveZs = Array(repeating: "Z", count: 5)
print(fiveZs)



//1.3 init(_:)

let numbers = Array(1...7)
print(numbers)



//1.4 init()

var emptyArray = Array<Int>()
print(emptyArray.isEmpty)

emptyArray = []
print(emptyArray.isEmpty)



//2.1 isEmpty

let horseName = "Silver"
if horseName.isEmpty {
    print("I've been through the desert on a horse with no name.")
} else {
    print("Hi ho, \(horseName)!")
}



//2.2 count

print("Count of number array is \(numbers.count)")



//2.3 capacity

print("Capacity of number array is \(numbers.capacity)")



//3.1 subscript

var streetsArray = ["Adams", "Bryant", "Channing", "Douglas", "Evarts"]
streetsArray[1] = "Butler"
print("Subscript 1 is \(streetsArray[1])")



//3.2 first

let numberArray = [10, 20, 30, 40, 50]
if let firstNumber = numberArray.first {
    print("FirstNumber is \(firstNumber)")
}



//3.3 last

if let lastNumber = numberArray.last {
    print("Last number in array is \(lastNumber)")
}



//3.4 subscript(_:)

let streetArr = ["Adams", "Bryant", "Channing", "Douglas", "Evarts"]
let streetsSlice = streetArr[2 ..< streetArr.endIndex]
print(streetsSlice)

let i = streetsSlice.index(of: "Evarts")
print(streetArr[i!])



//4.1 append(_:)

var numberArray1 = [1, 2, 3, 4, 5]
numberArray1.append(100)
print(numberArray1)



//4.2 append(contentsOf:)

numberArray1.append(contentsOf: 10...15)
print(numberArray1)



//4.3 insert(_:at:)

numberArray1.insert(100, at: 3)
numberArray1.insert(200, at: numberArray1.endIndex)

print(numberArray1)



//4.4 insert(contentsOf:at:)

numberArray1.insert(contentsOf: 100...103, at: 3)
print(numberArray1)



//4.5 replaceSubrange(_:with:)

var nums = [10, 20, 30, 40, 50]
nums.replaceSubrange(1...3, with: repeatElement(1, count: 5))
print(nums)



//4.6 reserveCapacity(_:)

var values: [Int] = [0, 1, 2, 3]

func addTenQuadratic() {
    let newCount = values.count + 10
    values.reserveCapacity(newCount)
    for n in values.count..<newCount {
        values.append(n)
    }
}
print(values)



//5.1 remove(at:)

var measurements: [Double] = [1.1, 1.5, 2.9, 1.2, 1.5, 1.3, 1.2]
let removed = measurements.remove(at: 2)
print(measurements)



//5.2 removeFirst(_:)

var bugs = ["Aphid", "Bumblebee", "Cicada", "Damselfly", "Earwig"]
bugs.removeFirst(3)
print(bugs)



//5.3 removeLast(_:)

bugs.removeLast(1)
print(bugs)



//5.4 removeSubrange(_:)

var measurements1 = [1.2, 1.5, 2.9, 1.2, 1.5]
measurements1.removeSubrange(1..<4)
print(measurements1)



//5.5 removeAll(keepingCapacity:_)

measurements1.removeAll()
print(measurements1)



//6.1 contains(where:)

enum HTTPResponse {
    case ok
    case error(Int)
}

let lastThreeResponses: [HTTPResponse] = [.ok, .ok, .error(404)]
let hadError = lastThreeResponses.contains { element in
    if case .error = element {
        return true
    } else {
        return false
    }
}
print(hadError)



//6.2 first(where:)

let numbers1 = [3, 7, 4, -2, 9, -6, 10, 1]
if let firstNegative = numbers1.first(where: { $0 < 0 }) {
    print("The first negative number is \(firstNegative).")
}



//6.3 index(of:_)

var students = ["Ben", "Ivy", "Jordell", "Maxime"]
if let i = students.index(of: "Maxime") {
    students[i] = "Max"
}
print(students)



//6.4 min(_:)

let heights = [67.5, 65.7, 64.3, 61.1, 58.5, 60.3, 64.9]
let lowestHeight = heights.min()
print(lowestHeight ?? "none")



//6.5 min(by:)

let hues = ["Heliotrope": 296, "Coral": 16, "Aquamarine": 156]
let leastHue = hues.min { a, b in a.value < b.value }
print(leastHue!)



//6.6 max(_:)

let greatestHeight = heights.max()
print(greatestHeight!)



//6.7 max(by:)

let greatestHue1 = hues.max { a, b in a.value < b.value }
print(greatestHue1!)



//7.1 prefix(_:)

let numbersA = [1, 2, 3, 4, 5]
print(numbersA.prefix(2))



//7.2 prefix(through:)

let numbersAr = [10, 20, 30, 40, 50, 60]
if let i = numbersAr.index(of: 40) {
    print(numbersAr.prefix(through: i))
}



//7.3 suffix(_:)

print(numbersA.suffix(2))



//7.4 suffix(from:)

let numbersS = [10, 20, 30, 40, 50, 60]
if let i = numbersS.index(of: 40) {
    print(numbersS.suffix(from: i))
}



//8.1 forEach(_:)

let numberWords = ["one", "two", "three"]
for word in numberWords {
    print(word)
}



//8.2 enumerated()

for (n, c) in "Swift".enumerated() {
    print("\(n): '\(c)'")
}



//9.1 sort()

var students1 = ["Kofi", "Abena", "Peter", "Kweku", "Akosua"]
students1.sort()
print(students1)



//9.2 sort(by:)

enum HTTPResponse1 {
    case ok
    case error(Int)
}

var responses: [HTTPResponse1] = [.error(500), .ok, .ok, .error(404), .error(403)]
responses.sort {
    switch ($0, $1) {
    // Order errors by code
    case let (.error(aCode), .error(bCode)):
        return aCode < bCode
        
    // All successes are equivalent, so none is before any other
    case (.ok, .ok): return false
        
    // Order errors before successes
    case (.error, .ok): return true
    case (.ok, .error): return false
    }
}
print(responses)



//9.3 sorted()

let studentsT: Set = ["Kofi", "Abena", "Peter", "Kweku", "Akosua"]
let sortedStudents = studentsT.sorted()
print(sortedStudents)



//9.4 reversed()

let numbersC = [3, 5, 7]
for number in numbersC.reversed() {
    print(number)
}



//10.1 dropFirst()

let numbersW = [1, 2, 3, 4, 5]
print(numbersW.dropFirst())



//10.2 dropLast()

print(numbersW.dropLast())



//11.1 startIndex

print(numbersW.startIndex)



//11.2 endIndex

print(numbersW.endIndex)



//12.1

let line = "BLANCHE:   I don't want realism. I want magic!"
print(line.split(separator: " ") .map(String.init))




//12.2 split(maxSplits:omittingEmptySubsequences:whereSeparator:)

print(line.split(whereSeparator: { $0 == "a" }))




//12.3 joined(separator:)

let cast = ["Vivien", "Marlon", "Kim", "Karl"]
let list = cast.joined(separator: ", ")
print(list)




// 12.4 joined()

let ranges = [0..<3, 8..<10, 15..<17]
for range in ranges {
    print(range)
}
for index in ranges.joined() {
    print(index, terminator: " ")
}




//13.1 Compare Arrays - ==(_:_:)

let arr1 = [1, 2, 2, 3, 4, 5]
let arr2 = [1, 3, 6, 7, 9 ,10]
if (arr1 == arr2){
    print("EQUAL ARRAY\(arr1)")
}else{
    print("NOT EQUAL")
}




//13.2 !=(_:_:)

if (arr1 != arr2){
    print("Not EQUAL ARRAY")
}else{
    print(" EQUAL")
}




//13.3 elementsEqual(_:)

if (arr1.elementsEqual(arr2)){
    print("equal elements")
}else{
    print("Not equal")
}




//13.4 starts(with:)


let a = 1...3
let b = 1...10

print(b.starts(with: a))




//13.5  lexicographicallyPrecedes(_:)

let ax = [1, 2, 2, 2]
let bx = [1, 2, 3, 4]

print(ax.lexicographicallyPrecedes(bx))

print(bx.lexicographicallyPrecedes(bx))




//14.1 description

print(ax.description)




//14.2 debugDescription

print(ax.debugDescription)




//14.3 customMirror

print(ax.customMirror)




//15. Bridging Between Array and NSArray
import Foundation
var arr : NSMutableArray = ["Pencil", "Eraser", "Notebook"]

func bar (a : NSMutableArray)
{
    a[2] = "Pen"
}

bar(a : arr)

print (Array(arr))

