//: Playground - noun: a place where people can play
// 1.1 Bitwise NOT Operator

let intialBits : UInt8 = 0b11110000
let invertBits = ~intialBits
print("Initial bits are:",intialBits)
print("Invert bits after applying ~ operator are:",invertBits)


//1.2 Bitwise AND Operator

let inputA : UInt8 = 0b00000110
let inputB : UInt8 = 0b00000101
let result1 = inputA & inputB
print("Result after applying & operator:",result1)


//1.3 Bitwise OR Operator

let result2 = inputA | inputB
print("Result after applying | operator:",result2)


//1.4 Bitwise XOR Operator

let result3 = inputA ^ inputB
print("Result after applying ^ operator:",result3)


//2. Left or Right Shift Operator

let shiftBits: UInt8 = 4
print("After shifting bits  to left by 1:",shiftBits << 1)
print("After shifting bits to right by 1:", shiftBits >> 1)
print("After shifting bits  to left by 4:",shiftBits << 4)
print("After shifting bits to right by 4:", shiftBits >> 4)

//3.1 Overflow Addition operator

// Uncommenting this code will show an overflow error:

// var num = Int32.max
// num += 1
// print(num)

//After using overflow addition operator:

var overflownum = UInt8.max
overflownum = overflownum &+ 1
print("After using overflow addition operator &+:",overflownum)


//3.2 Overflow Subtraction Operator

var overflownum2 = UInt8.min
overflownum2 = overflownum2 &- 1
print("After using overflow subtraction operator &-: ",overflownum2)


// 4. Operator Precedence and Associativity

var result = 34 + 2 % 6 * 3
print(result)

// 5.1 Swift Prefix Operator Method

struct Conversion {
    var number = 0.0
}
prefix func - (ConvertNum: Conversion) -> Conversion {
    return Conversion(number: -ConvertNum.number)
}
let pos = Conversion(number: 5.0)
print(pos)
let neg = -pos
print(neg)

// 5.2 Swift Compound Assignment Operator

struct Vector2D {
    var x = 0.0, y = 0.0
}

extension Vector2D {
    static func + (left: Vector2D, right: Vector2D) -> Vector2D {
        return Vector2D(x: left.x + right.x, y: left.y + right.y)
    }
}

extension Vector2D {
    static func += (left : inout Vector2D, right: Vector2D) {
        left = left + right
    }
}

let vector = Vector2D(x: 3.0, y: 1.0)
print(vector)
let anotherVector = Vector2D(x: 2.0, y: 4.0)
print(anotherVector)
let combinedVector = vector + anotherVector
print(combinedVector)


// 5.2 Swift Equivalence Operator

extension Vector2D {
    static func == (left: Vector2D, right: Vector2D) -> Bool {
        return (left.x == right.x) && (left.y == right.y)
    }
    static func != (left: Vector2D, right: Vector2D) -> Bool {
        return !(left == right)
    }
}

let twoThree = Vector2D(x: 2.0, y: 3.0)
let anotherTwoThree = Vector2D(x: 2.0, y: 3.0)
if twoThree == anotherTwoThree {
    print("These two vectors are equivalent.")
}

// 5.4 Swift custom operator

prefix operator +++
extension Vector2D {
    static prefix func +++ (vector: inout Vector2D) -> Vector2D {
        vector += vector
        return vector
    }
}

var toBeDoubled = Vector2D(x: 1.0, y: 4.0)
print(toBeDoubled)
let afterDoubling = +++toBeDoubled
print(afterDoubling)
