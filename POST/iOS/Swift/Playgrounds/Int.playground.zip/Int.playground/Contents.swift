// 1. Declaring Constants and Variables

let constantNum = 10
var variableNum = 10
print("constant data type value: \(constantNum)")
print("variable data type value before change :\(variableNum)")
variableNum = 40
print("variable data type value after change :\(variableNum)")

//2. Type Annotations

let number1 : Int = 100
print(number1)

//3. Naming Constants and Variables

let n = 10
print(n)
let 你好 = 145
print(你好)
let 🐶🐮 = 20000
print(🐶🐮)

//4. Converting Floating-Point Values

let x = Int(21.5)
print(x)
let y = Int(-21.5)
print(y)

//5.1 Performing Calculations - Integer Operators

print(x + y)
print(x - y)
print(x * y)
print(x / y)
print(x >> y)
print(x ^ y)

//5.2 negate()

var z = 30
print(z)
z.negate()
print(z)

//6.1 magnitude

print(y.magnitude)

//6.2 abs()

print(abs(y))

//6.3 signum()

print(y.signum())

//7.1 description

print(y.description)

//7.2 hashValue

print(y.hashValue)

//7.3 customMirror

print(y.customMirror)

//7.4 customPlaygroundQuickLook

print(y.customPlaygroundQuickLook)

//8.1 words

print(y.words)

//9.1 distance(to:)

print(y.distance(to: 2))

//9.2 advanced(to:)

print(y.advanced(by: 3))

//10.1 bitWidth

print(y.bitWidth)

//10.2 nonzeroBitCount

let l: Int8 = 0b0001_1111
print(l.nonzeroBitCount)

//10.3 leadingZeroBitCount

print(l.leadingZeroBitCount)

//10.4 trailingZeroBitCount

print(l.trailingZeroBitCount)

//11.1 byteSwapped

print(l.byteSwapped)

//11.2 littleEndian

print(l.littleEndian)

//11.3 bigEndian

print(l.bigEndian)
