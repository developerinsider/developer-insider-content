//: Playground - noun: a place where people can play

import UIKit

//1. Initializers

struct Name {
    var fName: String
    var lNAme: String
    init() {
        fName = "Vineeta"
        lNAme = "Bajaj"
    }
}
var name = Name()
print("Name is \(name.fName) \(name.lNAme)")

class Addition{
    var firstVar: Int
    var secondVar: Int
    init(first: Int, second: Int){
        firstVar = first
        secondVar = second
    }
}

var add = Addition(first: 40, second: 50)
print("Addition is :\(add.firstVar + add.secondVar)")

// 1.1. Default Property Values

struct Fahrenheit {
    var temperature = 32.0
}
var f = Fahrenheit()
print("Temperature is\(f.temperature)")

// 1.2  Customizing Initialization

struct Celsius {
    var temperatureInCelsius: Double
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32.0) / 1.8
    }
    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
}
let boilingPointOfWater = Celsius(fromFahrenheit: 212.0)
print("boilingPointOfWater.temperatureInCelsius: \(boilingPointOfWater.temperatureInCelsius)")

let freezingPointOfWater = Celsius(fromKelvin: 273.15)
print("freezingPointOfWater.temperatureInCelsius: \(freezingPointOfWater.temperatureInCelsius)")


// 1.3 Parameter Names and Argument Labels
struct Color {
    let red, green, blue: Double
    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }
    init(white: Double) {
        red   = white
        green = white
        blue  = white
    }
}
let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
print(magenta)
let halfGray = Color(white: 0.5)
print(halfGray)

// 1.4 Initializer Parameters Without Argument Labels
struct Celsiuss {
    var temperatureInCelsius: Double
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32.0) / 1.8
    }
    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}
let bodyTemperature = Celsiuss(37.0)
print(bodyTemperature)


// 1.5 Optional Property Types

class SurveyQuestion {
    var text: String
    var response: String?
    init(text: String) {
        self.text = text
    }
    func ask() {
        print(text)
    }
}
let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask()
cheeseQuestion.response = "Yes, I do like cheese."


// 2. Default Initializer

class ShoppingListItem {
    var name: String?
    var quantity = 1
    var purchased = false
}
var item = ShoppingListItem()
print("Quantity: \(item.quantity)")

// 2.1  Memberwise Initializers for Structure Types

struct Size {
    var width = 0.0, height = 0.0
}
let twoByTwo = Size(width: 2.0, height: 2.0)
print("width:\(twoByTwo.width), height:\(twoByTwo.height)")


// 3. convenience init()

class Human {
    var name: String
    init(name: String) {
        self.name = name
    }
    
    // Convenience init intializes the designated init method
    convenience init() {
        self.init(name: "Bob Lee")
    }
}
let human = Human()
print(human.name)

// 3.2 Designated Initializers

class Food {
    var name: String
    init(name: String) {
        self.name = name
    }
    convenience init() {
        self.init(name: "[Unnamed]")
    }
}
let namedMeat = Food(name: "Bacon")
print(namedMeat.name)

class RecipeIngredient: Food {
    var quantity: Int
    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }
    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
print(oneMysteryItem.name)
let oneBacon = RecipeIngredient(name: "Bacon")
print(oneBacon.name)
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)
print(sixEggs.quantity)

//4. failable Initializer

struct Animal {
    let species: String
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}
let anonymousCreature = Animal(species: "")

if anonymousCreature == nil {
    print("The anonymous creature could not be initialized")
}

//5. Deinitialization

class SumUp{
    var varA: Int = 0
    var varB: Int = 0
    init(){
        varA = 20
        varB = -20
        print("Value of VarA and VarB after init : \(varA) , \(varB)")
    }
    
    deinit{
        print("Value of VarA and VarB after deinit : \(varA) , \(varB)")
    }
}

func createSumObj(){
    let _ = SumUp()
}

createSumObj()
