//Optionals Chainings by Example - Swift Programming Language
//Developer Insider (https://www.developerinsider.in)

import UIKit

//1. Introduction
var optionalName: String? = "Developer Insider"
print(optionalName)

var normalName: String = "Developer Insider" // No "?" after String
print(normalName)



//2. How to create optionals
var name: String? = "Developer Insider" // Create an optional String that contains "Developer Insider"

class Car {
    var modelName: String = "" // must exist
    var internalName: String? // may or may not exist
}
var myCar: Car? = Car() // An optional "Car" (custom type)



//3. Only optionals can be nil
optionalName = nil // Set name to nil, the absence of a value
// normalName = nil // error: nil cannot be assigned to type 'String'



//4. Forced Unwrapping
optionalName = "Developer Insider"
let unwrappedName = optionalName!
print("Unwrapped name: \(unwrappedName)")

optionalName = nil
//let nilName = optionalName!



//5. Optional Chaining
class Human {
    var name: String
    init(name: String) {
        self.name = name
    }
    
    func sayHello() {
        print("Hello, I'm \(name)")
    }
}

class Apartment {
    var human: Human?
}

var seoulApartment = Apartment()
seoulApartment.human = Human(name: "Vineet")

var myName = seoulApartment.human?.name
print(myName)

if let residentName = seoulApartment.human?.name {
    print(residentName) // non-optional
} else {
    print("No name available")
}
