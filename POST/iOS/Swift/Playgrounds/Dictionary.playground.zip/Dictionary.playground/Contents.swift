//1.1 Creating a dictionary - init()

var emptyDict: [String: String] = [:]
print(emptyDict.isEmpty)



//1.2 init(uniqueKeysWithValues:)

let digitWords = ["one", "two", "three", "four", "five"]
let wordToValue = Dictionary(uniqueKeysWithValues: zip(digitWords, 1...5))
print(wordToValue["three"]!)
print(wordToValue)



//1.3 init(_:uniquingKeysWith:)

let pairsWithDuplicateKeys = [("a", 1), ("b", 2), ("a", 3), ("b", 4)]
let firstValues = Dictionary(pairsWithDuplicateKeys, uniquingKeysWith: { (first, _) in first })
let lastValues = Dictionary(pairsWithDuplicateKeys, uniquingKeysWith: { (_, last) in last })
print(firstValues)
print(lastValues)


//1.4 init(grouping:by:)

let students = ["Kofi", "Abena", "Efua", "Kweku", "Akosua"]
let studentsByLetter = Dictionary(grouping: students, by: { $0.first! })
print(studentsByLetter)



//2.1 isEmpty

var frequencies: [String: Int] = [:]
print(frequencies.isEmpty)



//2.2 count

print(studentsByLetter.count)



//2.3 capacity
let dict = Dictionary<String, Any>(minimumCapacity: 20)
print(dict.capacity)




//3.1 subscript(_:)

var hues = ["Heliotrope": 296, "Coral": 16, "Aquamarine": 156]
print(hues["Coral"] ?? "default value")
print(hues["Cerise"] ?? "default value")



//3.2 index(forKey:)

let countryCodes = ["BR": "Brazil", "GH": "Ghana", "JP": "Japan"]
let index = countryCodes.index(forKey: "JP")

print("Country code for \(countryCodes[index!].value): '\(countryCodes[index!].key)'.")



//3.3 first

if let firstCountry = countryCodes.first {
    print("First value in dictionary is : \(firstCountry)")
}



//3.4 keys

for k in countryCodes.keys {
    print(k)
}


//3.5 values

for v in countryCodes.values {
    print(v)
}


//4.1 updateValue(_:forKey:)

if let oldValue = hues.updateValue(18, forKey: "Coral") {
    print("The old value of \(oldValue) was replaced with a new one.")
}


//4.2 merge(_:uniquingKeysWith:)

var dictionary = ["a": 1, "b": 2]

dictionary.merge(["a": 3, "c": 4]) { (current, _) in current }
print(dictionary)
dictionary.merge(["a": 5, "d": 6]) { (_, new) in new }
print(dictionary)


//4.3 merge(_:uniquingKeysWith:)

dictionary.merge(zip(["a", "c"], [3, 4])) { (current, _) in current }
print(dictionary)


dictionary.merge(zip(["a", "d"], [5, 6])) { (_, new) in new }
print(dictionary)



//4.4 merging(_:uniquingKeysWith:)

var otherDictionary = ["a": 3, "b": 4]

let keepingCurrent = dictionary.merging(otherDictionary)
{ (current, _) in current }
print(keepingCurrent)

let replacingCurrent = dictionary.merging(otherDictionary)
{ (_, new) in new }
print(replacingCurrent)




//5.1 removeValue(forKey:)

if let value = hues.removeValue(forKey: "Coral") {
    print("The value \(value) was removed.")
}


//5.2 removeAll(keepingCapacity:)

dictionary.removeAll(keepingCapacity: false)
print(dictionary)



//6.1 ==(:)

let dict1: Dictionary = [1: "one", 2: "two", 3: "three", 4: "four", 5: "five"]
let dict2: Dictionary = [1: "1", 2: "2", 3: "3",4: "4",5: "5"]
if(dict1 == dict2){
    print("equal")
}else{
    print("Not equal")
}

//6.2 !=(:)

if(dict1 != dict2){
    print("Not equal")
}else{
    print("equal")
}


//7.1 forEach(_:)

let numberWords = [1: "one",2: "two", 3: "three"]
for word in numberWords {
    print(word)
}

numberWords.forEach { word in
    print(word)
}

//7.2 enumerated()

for (n, c) in numberWords.enumerated() {
    print("\(n)-> 'key:\(c.key) value:\(c.value)'")
}


//8.1 contains(where:)

let containsThree = numberWords.contains { (key, value) -> Bool in
    return value == "three"
}
print(containsThree)



//8.2 first(where:)

let wordsNumber = ["MinusOne":-1, "zero":0, "one": 1, "two": 2, "three": 3]
if let firstNegative = wordsNumber.first(where: { $0.value < 0 }) {
    print("The first negative number is \(firstNegative).")
}


//8.3 min(by:)

let leastHue = hues.min { a, b in a.value < b.value }
print(leastHue!)


//8.4 max(by:)

let greatestHue = hues.max { a, b in a.value < b.value }
print(greatestHue!)


//9.1 description

print(dict1.description)



//9.2 debugDescription

print(dict1.debugDescription)



//9.3 customMirror

print(dict1.customMirror)

