/* An enumeration defines a common type for a group of related values and enables you to work with those values in a type-safe way within your code. */

//1. Basic Enumerations

//1.1 Create an enumerations
enum Direction {
    case up
    case down
    case left
    case right
}



//1.2 Initialization
var direction = Direction.up
direction = .down



//1.3 Matching Enumeration Values with a Switch Statement
direction = .left
switch direction {
case .up:
    print("up")
case .down:
    print("down")
case .left:
    print("left")
case .right:
    print("right")
}


//2. Enumerations with Raw Values

//2.1 Implicitly Assigned Raw Values
enum DirectionString: String {
    case up
    case down
    case left
    case right
}

let directionString = DirectionString.right.rawValue


enum Planet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune
}

let earthsOrder = Planet.earth.rawValue


//2.2 Initializing from a Raw Value
let possiblePlanet = Planet(rawValue: 3)


let positionToFind = 11
if let somePlanet = Planet(rawValue: positionToFind) {
    switch somePlanet {
    case .earth:
        print("Mostly harmless")
    default:
        print("Not a safe place for humans")
    }
} else {
    print("There isn't a planet at position \(positionToFind)")
}


//3. Enumerations with Associated Values

// 3.1 Create an Enumerations with Associated Values
enum Action {
    case jump
    case kick
    case move(distance: Float)
}

let action = Action.move(distance: 10.2)



// 3.2 Matching Enumeration Values with a Switch Statement
switch action {
case .jump:
    print("Jump")
case .kick:
    print("Kick")
case .move(let distance):  // or case let .move(distance):
    print("Moving: \(distance)")
}



// 3.3 Matching Enumeration Values with a if Statement
if case .move(let distance) = action {
    print("Moving: \(distance)")
}


// 3.4 Make Equatable Enums with Associated Values
extension Action: Equatable { }

func ==(lhs: Action, rhs: Action) -> Bool {
    switch lhs {
    case .jump: if case .jump = rhs { return true }
    case .kick: if case .kick = rhs { return true }
    case .move(let lhsDistance): if case .move (let rhsDistance) = rhs { return lhsDistance == rhsDistance }
    }
    return false
}

//Use of Equatable
if Action.move(distance: 10.2) == action {
    print("Moving Same Distance")
} else {
    print("Moving Different Distance")
}