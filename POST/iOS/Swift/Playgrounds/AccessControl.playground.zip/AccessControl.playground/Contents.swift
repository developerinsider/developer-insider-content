

import UIKit

// 1. open - access level

class BobbyViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        print("hello")
    }
}

let obj = BobbyViewController()
obj.viewDidLoad()

//3. internal

class Test1{
    internal var a = 30
    var b = 50
    init() {
        print("value of a and b",a,b)
    }
}

class Test2: Test1{
    var obj1 = Test1()
//  Uncomment next lines and it will show error unauthorized access
//    obj1.a = 40
//    obj1.b = 90
}
let obj2 = Test2()

// 4. fileprivate

// NewViewController.swift
fileprivate class NewViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

// ViewController.swift
class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // uncommenting next line will show an error as class is defined as fileprivate
        // let newViewController = NewViewController()
        let bobbyViewController = BobbyViewController()
        bobbyViewController.viewDidLoad()
    }
}

let viewController = ViewController()
viewController.viewDidLoad()


//5. private

class Game {
    private var number = 0
    
    func score() {
        print(number)
    }
    
    func increaseNumberByOne() {
        number += 1
    }
}
//uncommenting next line will show an error of inaccesibility
//Game().number
Game().score()

class MyClass: UIViewController{
    private var myClassVarA = 90
    override func viewDidLoad() {
        super.viewDidLoad()
        print("private variable:",myClassVarA)
    }
}
extension MyClass{
    func printValueOfA(){
        print("accessing private variable of same class in extension:",myClassVarA)
    }
}
let myClassObj = MyClass()
myClassObj.viewDidLoad()
myClassObj.printValueOfA()
